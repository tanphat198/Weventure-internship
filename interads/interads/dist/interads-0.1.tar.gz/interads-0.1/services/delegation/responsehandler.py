class ResponseHandler(object):
    def handle(self, response):
        pass

    def on_error(self, error, request):
        pass
