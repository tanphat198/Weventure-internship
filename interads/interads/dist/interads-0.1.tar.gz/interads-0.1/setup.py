import setuptools

setuptools.setup(
    name="interads",
    version="0.1",
    author="Phat Mnh",
    author_email="ntphat@apcs.vn",
    description="Sort description",
    long_description="Full description",
    long_description_content_type="text/markdown",
    url="https://github.com/tanphat198/Weventure-internship/tree/master/ExchangeRates",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)

