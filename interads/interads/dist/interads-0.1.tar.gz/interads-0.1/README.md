  Install offline:
pip intall interads-0.0.1.tar.gz
    Install qua pypi:
pip install interads
